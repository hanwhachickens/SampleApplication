package com.cookandroid.moblie_homework1;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText idInput;
    EditText passwordInput;
    SharedPreferences pref;
    String prefData;
    static String id = "";
    String password;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button loginButton = findViewById(R.id.loginButton);
        Button membershipButton = findViewById(R.id.membershipbutton);
        Button mainpageButton = findViewById(R.id.mainpagebutton);
        idInput = findViewById(R.id.idInput);
        passwordInput = findViewById(R.id.passwordInput);
        loginButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), homepageActivity.class);
                id = idInput.getText().toString();
                password = passwordInput.getText().toString();
                pref = getSharedPreferences("memberPref",MODE_PRIVATE);
                prefData = pref.getString(id,"");
                if (id.equals("")){
                    Toast.makeText(getApplicationContext(), "아이디를 입력해주세요.", Toast.LENGTH_SHORT).show();
                    idInput.requestFocus();
                } else if (password.equals("")){
                    Toast.makeText(getApplicationContext(), "비밀번호를 입력해주세요.", Toast.LENGTH_SHORT).show();
                    passwordInput.requestFocus();
                } else if (prefData.equals("")){
                    Toast.makeText(getApplicationContext(), "등록되지 않은 아이디입니다.", Toast.LENGTH_SHORT).show();
                    idInput.setText(id);
                    idInput.requestFocus();
                } else if (!prefData.equals(password)){
                    Toast.makeText(getApplicationContext(), "올바르지 않은 비밀번호입니다.", Toast.LENGTH_SHORT).show();
                    passwordInput.setText("");
                    passwordInput.requestFocus();
                } else {
                    Toast.makeText(getApplicationContext(), id+"님 환영합니다.", Toast.LENGTH_SHORT).show();
                    idInput.setText(id);
                    passwordInput.setText(password);
                    startActivity(intent);
                }
            }
        });

        membershipButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(), MembershipActivity.class);
                startActivity(intent);
            }
        });

        mainpageButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                id = "";
                Intent intent = new Intent(getApplicationContext(), homepageActivity.class);
                startActivity(intent);
            }
        });

    }
}