package com.cookandroid.moblie_homework1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

public class MembershipActivity extends AppCompatActivity {
    private TextView singagree;

    //뷰 객체 생성
    EditText idName, passwordName, personName, phonenumbName, addressName;
    Button okButton, checkingButton; //회원가입 버튼
    RadioButton agreeButton; //약관 동의 여부 체크 박스

    //변수 객체 생성
    String id, password, name, phonenumb, address, prefData;//아이디, 암호, 암호재입력 String
    int check = 0;

    SharedPreferences memberPref, pref;
    SharedPreferences.Editor editor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_membership);

        singagree = (TextView) findViewById(R.id.textView); //동의약관
        agreeButton = findViewById(R.id.radioButton5);
        idName = (EditText) findViewById(R.id.idName); //아이디
        passwordName = (EditText) findViewById(R.id.passwordName); //암호
        personName = (EditText) findViewById(R.id.personName);
        phonenumbName = (EditText) findViewById(R.id.phonenumbName);
        addressName = (EditText) findViewById(R.id.addressName);


        okButton = (Button) findViewById(R.id.okButton); //회원가입 버튼
        checkingButton = (Button) findViewById(R.id.checkingButton);

        okButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                id = idName.getText().toString(); //아이디
                password = passwordName.getText().toString(); //비밀번호
                name = personName.getText().toString();
                phonenumb = phonenumbName.getText().toString();
                address = addressName.getText().toString();
                pref = getSharedPreferences("memberPref", MODE_PRIVATE);
                prefData = pref.getString(id, "");
                if (prefData != "") {
                    Toast.makeText(getApplicationContext(), "아이디 중복확인을 해주세요.", Toast.LENGTH_SHORT).show();
                    idName.requestFocus();
                } else if (password.length()>10){
                    Toast.makeText(getApplicationContext(), "10자리 이하의 비밀번호를 입력해주세요.", Toast.LENGTH_SHORT).show();
                    passwordName.requestFocus();
                } else if (!agreeButton.isChecked()) {
                    //약관동의를 안했다면 실행
                    Toast.makeText(getApplicationContext(), "약관을 읽고 동의 해주세요.", Toast.LENGTH_SHORT).show();
                    //checkbox2로 이동
                    agreeButton.requestFocus();

                } else if (id.equals("")) {
                    Toast.makeText(getApplicationContext(), "아이디를 입력해주세요.", Toast.LENGTH_SHORT).show();
                    //signid로 커서 이동
                    idName.requestFocus();

                } else if (password.equals("")) {
                    Toast.makeText(getApplicationContext(), "비밀번호를 입력해주세요.", Toast.LENGTH_SHORT).show();
                    //signpassword로 커서 이동
                    passwordName.requestFocus();

                } else if (name.equals("")){
                    Toast.makeText(getApplicationContext(), "이름을 입력해주세요.", Toast.LENGTH_SHORT).show();
                    personName.requestFocus();
                } else if (phonenumb.equals("")) {
                    Toast.makeText(getApplicationContext(), "전화번호를 입력해주세요.", Toast.LENGTH_SHORT).show();
                    phonenumbName.requestFocus();
                } else if (address.equals("")) {
                    Toast.makeText(getApplicationContext(), "주소를 입력해주세요.", Toast.LENGTH_SHORT).show();
                    addressName.requestFocus();
                } else {
                    //회원가입 정보를 모두 입력 했다면 회원가입 정보 쉐어드에 저장
                    signCheck();
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);

                }


            }
        });

        checkingButton.setOnClickListener(new View.OnClickListener(){
           public void onClick(View v){
               check = 1;
               id = idName.getText().toString();
               pref = getSharedPreferences("memberPref",MODE_PRIVATE);
               prefData = pref.getString(id,"");
               if (prefData != ""){
                   Toast.makeText(getApplicationContext(),"중복된 아이디입니다.", Toast.LENGTH_SHORT).show();
                   idName.setText("");
                   check = 0;
               }
               else {
                   Toast.makeText(getApplicationContext(), "생성 가능한 아이디입니다.", Toast.LENGTH_SHORT).show();
               }
           }
        });

    }

    //회원 가입 정보 쉐어드에 저장
    protected void signCheck() {
        memberPref = this.getSharedPreferences("memberPref", MembershipActivity.MODE_PRIVATE);
        editor = memberPref.edit();
        editor.putString(id, password);
        editor.commit();
    }
}