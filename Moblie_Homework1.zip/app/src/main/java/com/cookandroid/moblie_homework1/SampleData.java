package com.cookandroid.moblie_homework1;

import android.widget.ImageView;

public class SampleData {
    private int image;
    private String imageName;

    public SampleData(int image, String imageName){
        this.image = image;
        this.imageName = imageName;
    }

    public int getimage()
    {
        return this.image;
    }

    public String getimageName()
    {
        return this.imageName;
    }
}