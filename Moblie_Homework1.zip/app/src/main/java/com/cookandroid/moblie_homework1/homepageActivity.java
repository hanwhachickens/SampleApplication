package com.cookandroid.moblie_homework1;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class homepageActivity extends AppCompatActivity {
    static ImageView imageView;
    ArrayList<SampleData> imageDataList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);

        ListView listView = findViewById(R.id.listview);
        Button addButton = findViewById(R.id.addButton);
        Button deleteButton = findViewById(R.id.deleteButton);
        Button memberButton = findViewById(R.id.memberButton);
        this.ImageData();

        final MyAdapter myAdapter = new MyAdapter(this,imageDataList);
        AlertDialog.Builder msg = new AlertDialog.Builder(this);
        listView.setAdapter(myAdapter);
        memberButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (MainActivity.id.equals("")){
                    msg.setTitle("회원 정보");
                    msg.setMessage("로그인이 되어있지 않습니다.");
                    msg.setPositiveButton("회원가입", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Intent intent = new Intent(getApplicationContext(), MembershipActivity.class);
                            startActivity(intent);
                        }
                    });
                    msg.setNegativeButton("취소", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {

                        }
                    });
                    msg.create().show();
                }
                else {
                    msg.setTitle("회원 정보");
                    msg.setMessage("아이디 : " + MainActivity.id);
                    msg.create().show();
                }
            }
        });
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(intent, 1);
            }
        });

    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // Check which request we're responding to
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            // Make sure the request was successful
            if (resultCode == RESULT_OK) {
                try {
                    // 선택한 이미지에서 비트맵 생성
                    InputStream in = getContentResolver().openInputStream(data.getData());
                    Bitmap img = BitmapFactory.decodeStream(in);
                    in.close();
                    // 이미지 표시
                    imageView.setImageBitmap(img);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }


    public void ImageData()
    {
        imageDataList = new ArrayList<SampleData>();

        imageDataList.add(new SampleData(R.drawable.adidas, "아디다스"));
        imageDataList.add(new SampleData(R.drawable.fila, "휠라"));
        imageDataList.add(new SampleData(R.drawable.gucci, "구찌"));
        imageDataList.add(new SampleData(R.drawable.nike, "나이키"));
        imageDataList.add(new SampleData(R.drawable.underarmour, "언더아머"));
    }
}